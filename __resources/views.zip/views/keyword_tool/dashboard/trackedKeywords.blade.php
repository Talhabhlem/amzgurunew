<style>
    .removeProductLink {
        cursor: pointer;
    }
</style>
<br>

<div class="row" >
    <div class="col-md-10 col-md-offset-1 rcorners" style="background:white" height="400px">
        <div id="detailTitle" class="logo" style="padding: 0; margin-top: 0.5em; margin-bottom:-10px" align="center">
            tracked products & keywords
            <span style="float:right"><a href="http://stats.ecommelite.com/addProduct">+ Add Product</a></span>
        </div>
        <hr>
        {{--<table id="example" class="display" cellspacing="0">--}}
        <div style="width:100%">
            <table id="example" class="display" cellspacing="0" width="100%">
                <thead>
                <tr>
                    <th>Image</th>
                    <th>Title</th>
                    <th>Asin</th>
                    <th>Keyword</th>
                    <th>Updated</th>
                    <th>Remove</th>
                </tr>
                </thead>

                <tbody>
                <tr>
                    <td>1</td>
                    <td>2</td>
                    <td>3</td>
                </tr>
                </tbody>
            </table>
        </div>
        <br>
    </div>
</div>

<br>
<br>