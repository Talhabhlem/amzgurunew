<div class="panel panel-default">
  <div class="panel-heading">Welcome to my module!</div>
  <div class="panel-body">
    I was added to the Dashboard without changing LaravelCP :D
  </div>
</div>