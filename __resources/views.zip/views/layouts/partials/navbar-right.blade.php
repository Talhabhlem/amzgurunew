<li><a href="#search" class="nav-search"><i class="fa fa-search"></i></a></li>
<li class="dropdown">
    <a class="dropdown-toggle" data-toggle="dropdown" href="#">
        <i class="fa fa-user fa-fw"></i>  <i class="fa fa-caret-down"></i>
    </a>
    <ul class="dropdown-menu dropdown-messages">
        <li>
            <a href="{{ url('/auth/logout') }}">
               <i class="fa fa-sign-out"></i> Logout
            </a>
        </li>
    </ul>
    <!-- /.dropdown-messages -->
</li>
