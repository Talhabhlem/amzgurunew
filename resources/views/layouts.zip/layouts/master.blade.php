<!DOCTYPE html>
<html class="no-js css-menubar" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="keywords" content="@yield('keywords')">
    <meta name="author" content="@yield('author')">
    <meta name="description" content="@yield('description')">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="_token" content="{{ csrf_token() }}">
    <title>@yield('title', trans('lcp::app.title'))</title>

    <link rel="apple-touch-icon" href="{!!url('assets/images/apple-touch-icon.png')!!}">
    <link rel="shortcut icon" href="{!!url('assets/images/favicon.ico')!!}">

    <!-- Stylesheets -->
    <link rel="stylesheet" href="{!!url('assets/css/bootstrap.min.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/css/bootstrap-extend.min.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/css/site.min.css')!!}">

    <!-- Plugins -->
    <link rel="stylesheet" href="{!!url('assets/vendor/animsition/animsition.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/asscrollable/asScrollable.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/switchery/switchery.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/intro-js/introjs.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/slidepanel/slidePanel.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/flag-icon-css/flag-icon.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/bootstrap-datepicker/bootstrap-datepicker.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/vendor/jquery-labelauty/jquery-labelauty.css')!!}">

    <link rel="stylesheet" href="{!!url('assets/examples/css/structure/ribbon.css')!!}">

    <link href="{!!url('assets/fonts/font-awesome/font-awesome.css')!!}" type="text/css" rel="stylesheet"/>

    <!-- Fonts -->
    <link rel="stylesheet" href="{!!url('assets/fonts/web-icons/web-icons.min.css')!!}">
    <link rel="stylesheet" href="{!!url('assets/fonts/brand-icons/brand-icons.min.css')!!}">
    <link rel='stylesheet' href='http://fonts.googleapis.com/css?family=Roboto:300,400,500,300italic'>

    <link rel="stylesheet" href="{!!url('assets/daterangepicker/daterangepicker.css')!!}" type="text/css"/>
    <link rel="stylesheet" href="{!!url('assets/select2-4.0.0/css/select2.min.css')!!}" type="text/css"/>
    <link rel="stylesheet" href="{!!url('assets/css/custom.css')!!}" type="text/css"/>

    <script src="{!!url('assets/js/jquery.js')!!}"></script>
    <!--[if lt IE 9]>
    <script src="{!!url('assets/vendor/html5shiv/html5shiv.min.js')!!}"></script>
    <![endif]-->

    <!--[if lt IE 10]>
    <script src="{!!url('assets/vendor/media-match/media.match.min.js')!!}"></script>
    <script src="{!!url('assets/vendor/respond/respond.min.js')!!}"></script>
    <![endif]-->

    <!-- Scripts -->
    <script src="{!!url('assets/vendor/modernizr/modernizr.js')!!}"></script>
    <script src="{!!url('assets/vendor/breakpoints/breakpoints.js')!!}"></script>
    <script>
        Breakpoints();
    </script>
    <script type="text/javascript">
        base_url = '{!! url() !!}/';
        var thisTimeZone = 'America/Los_Angeles';
    </script>

    <link rel="stylesheet" href="{!! url('/assets/css/app.css') !!}">
    @yield('styles')
    @yield('head')
    <script>
        var LNG_ARE_YOU_SURE = "{{ trans('lcp::default.areyousure') }}";
    </script>
</head>
<body>

<!--[if lt IE 8]>
<p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade
    your browser</a> to improve your experience.</p>
<![endif]-->

@section('header')
@show

@section('wrapper')
    <div id="wrapper">
        @section('before')
            @include('layouts.partials.before')
        @show

        @section('navbar-static-top')
            <nav class="site-navbar navbar navbar-default navbar-fixed-top navbar-mega" role="navigation">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle hamburger hamburger-close navbar-toggle-left hided"
                            data-toggle="menubar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="hamburger-bar"></span>
                    </button>
                    <button type="button" class="navbar-toggle collapsed" data-target="#site-navbar-collapse"
                            data-toggle="collapse">
                        <i class="icon wb-more-horizontal" aria-hidden="true"></i>
                    </button>
                    <div class="navbar-brand navbar-brand-center site-gridmenu-toggle" data-toggle="gridmenu">
                        <img class="navbar-brand-logo" src="{!!url('assets/images/logo.png')!!}" title="Ecomm Elite">
                        <span class="navbar-brand-text"> EcommElite</span>
                    </div>
                    <button style="" type="button" class="navbar-toggle collapsed" data-target="#site-navbar-search"
                            data-toggle="collapse">
                        <span class="sr-only">Toggle Search</span>
                        <i class="icon wb-search" aria-hidden="true"></i>
                    </button>
                </div>


                <div class="navbar-container container-fluid">
                    <!-- Navbar Collapse -->
                    <div class="collapse navbar-collapse navbar-collapse-toolbar" id="site-navbar-collapse">
                        <!-- Navbar Toolbar -->
                        <ul class="nav navbar-toolbar">
                            <li class="hidden-float" id="toggleMenubar">
                                <a data-toggle="menubar" href="#" role="button">
                                    <i class="icon hamburger hamburger-arrow-left">
                                        <span class="sr-only">Toggle menubar</span>
                                        <span class="hamburger-bar"></span>
                                    </i>
                                </a>
                            </li>
                            <li class="hidden-xs" id="toggleFullscreen">
                                <a class="icon icon-fullscreen" data-toggle="fullscreen" href="#" role="button">
                                    <span class="sr-only">Toggle fullscreen</span>
                                </a>
                            </li>
                            @section('top_header_data_status')
                                @if(!$cuser->is('admin'))
                                    @include('partials.top-left-nav-bar-links')
                                @endif
                            @show
                        </ul>
                        <!-- End Navbar Toolbar -->

                        <!-- Navbar Toolbar Right -->
                        <ul class="nav navbar-toolbar navbar-right navbar-toolbar-right">
                            <li class="dropdown">
                                <a class="dropdown-toggle" data-toggle="dropdown" href="#" aria-expanded="false"
                                   role="button">
                                    <strong>
                                        <i class="fa fa-user"
                                           style="float:left; display:inline-block; line-height:1.5; margin-right:5px;"></i>
                                        {{$cuser->first_name.' '.$cuser->last_name}}
                                    </strong>
                                    <span class="caret"></span></a>
                                    <ul class="dropdown-menu" role="menu">
                                        <li><a href="<?php echo url('settings/changepassword'); ?>"><i
                                                        class="icon fa fa-lock"></i>Change Password</a></li>
                                        <li class="divider" role="presentation"></li>
                                        <li><a href="<?php echo url('auth/logout'); ?>"><i class="icon wb-power"></i>Logout</a>
                                        </li>
                                    </ul>
                            </li>

                            <li class="bg-blue-600 white">
                                <a class="white" href="<?php echo url('auth/logout'); ?>">
                                    <i class="icon wb-power">
                                    </i>
                                </a>
                            </li>

                        </ul>
                        <!-- End Navbar Toolbar Right -->
                    </div>
                    <!-- End Navbar Collapse -->

                    <!-- Site Navbar Seach -->
                    <div class="collapse navbar-search-overlap" id="site-navbar-search">
                        <form role="search">
                            <div class="form-group">
                                <div class="input-search">
                                    <i class="input-search-icon wb-search" aria-hidden="true"></i>
                                    <input type="text" class="form-control" name="site-search" placeholder="Search...">
                                    <button type="button" class="input-search-close icon wb-close"
                                            data-target="#site-navbar-search"
                                            data-toggle="collapse" aria-label="Close"></button>
                                </div>
                            </div>
                        </form>
                    </div>
                    <!-- End Site Navbar Seach -->
                </div>
            </nav>

        @section('navbar-top-links')

            <div class="site-menubar">
                <div class="site-menubar-body">
                    <ul class="site-menu">
                        @include('layouts.partials.side-menu')
                        @yield('navbar-right')
                    </ul>
                    <div class="site-menubar-section" style="display: none;">
                        <h5>
                            Milestone
                            <span class="pull-right">30%</span>
                        </h5>

                        <div class="progress progress-xs">
                            <div class="progress-bar active" style="width: 30%;" role="progressbar"></div>
                        </div>
                        <h5>
                            Release
                            <span class="pull-right">60%</span>
                        </h5>
                        <div class="progress progress-xs">
                            <div class="progress-bar progress-bar-warning" style="width: 60%;" role="progressbar"></div>
                        </div>
                    </div>
                </div>
                <div class="site-menubar-footer">
                    @yield('site-menu-footer')
                </div>
            </div>
            <div class="site-gridmenu">
                <div>
                    <div>
                        <ul>
                            @include('layouts.partials.side-menu')
                        </ul>
                    </div>
                </div>
            </div>
        @show
        @show

        @section('page-wrapper-wrap')
            <div class="page animsition">
                @section('before_page_content')
                @show
                <div class="page-header">
                    @section('page-header')
                    <div class="clearfix">
                        <h1 class="page-title pull-left">@yield('page_title')</h1>
                    </div>
                        @show
                </div>
                @section('page-wrapper')
                    <div class="page-content">
                        <div class="panel">
                            <div class="panel-body padding-left-0 padding-right-0 padding-top-0" id="panel-body-div">
                                <div class="example-wrap" >
                                    @yield('content')
                                </div>
                            </div>
                        </div>
                    </div>
                @show
            </div>
        @show
        @section('after')
            @include('layouts.partials.after')
        @show
    </div>
@show

@section('footer')
@show

        <!-- Footer -->
<footer class="site-footer">
    <span class="site-footer-legal">
        © 2015 EcommElite
    </span>
    <div class="site-footer-right" style="display: none;">
        Developed by <a href="http://techesthete.net">techesthete</a>
    </div>
</footer>

<!-- Core  -->
<script src="{!!url('assets/vendor/bootstrap/bootstrap.js')!!}"></script>
<script src="{!!url('assets/vendor/animsition/jquery.animsition.js')!!}"></script>
<script src="{!!url('assets/vendor/asscroll/jquery-asScroll.js')!!}"></script>
<script src="{!!url('assets/vendor/mousewheel/jquery.mousewheel.js')!!}"></script>
<script src="{!!url('assets/vendor/asscrollable/jquery.asScrollable.all.js')!!}"></script>
<script src="{!!url('assets/vendor/ashoverscroll/jquery-asHoverScroll.js')!!}"></script>

<!-- Plugins -->
<script src="{!!url('assets/vendor/switchery/switchery.min.js')!!}"></script>
<script src="{!!url('assets/vendor/intro-js/intro.js')!!}"></script>
<script src="{!!url('assets/vendor/screenfull/screenfull.js')!!}"></script>
<script src="{!!url('assets/vendor/slidepanel/jquery-slidePanel.js')!!}"></script>

<!-- Plugins For This Page -->
<script src="{!!url('assets/vendor/peity/jquery.peity.min.js')!!}"></script>

<!-- Scripts -->
<script src="{!!url('assets/js/core.js')!!}"></script>
<script src="{!!url('assets/js/site.js')!!}"></script>

<script src="{!!url('assets/js/sections/menu.js')!!}"></script>
<script src="{!!url('assets/js/sections/menubar.js')!!}"></script>
<script src="{!!url('assets/js/sections/gridmenu.js')!!}"></script>
<script src="{!!url('assets/js/sections/sidebar.js')!!}"></script>

<script src="{!!url('assets/js/configs/config-colors.js')!!}"></script>
<script src="{!!url('assets/js/configs/config-tour.js')!!}"></script>

<script src="{!!url('assets/js/components/asscrollable.js')!!}"></script>
<script src="{!!url('assets/js/components/animsition.js')!!}"></script>
<script src="{!!url('assets/js/components/slidepanel.js')!!}"></script>
<script src="{!!url('assets/js/components/switchery.js')!!}"></script>

<!-- Plugins For This Page -->
<script src="{!!url('assets/vendor/jquery-placeholder/jquery.placeholder.js')!!}"></script>


<!-- Scripts For This Page -->
<script src="{!!url('assets/js/components/peity.js')!!}"></script>
<script src="{!!url('assets/js/components/selectable.js')!!}"></script>
<script src="{!!url('assets/js/components/table.js')!!}"></script>

<script src="{!!url('assets/examples/js/charts/peity.js')!!}"></script>

<!-- this page specific scripts -->
<script src="{!!url('assets/daterangepicker/moment.min.js')!!}"></script>
<script src="{!!url('assets/daterangepicker/moment.timezone.js')!!}"></script>
<script src="{!!url('assets/daterangepicker/daterangepicker.js')!!}"></script>
<script src="{!!url('assets/js/form-validator.js')!!}"></script>

<!-- Scripts For This Page -->
<script src="{!!url('assets/js/components/jquery-placeholder.js')!!}"></script>
<script src="{!!url('assets/js/components/material.js')!!}"></script>

<!-- Scripts For This Page -->
<script src="{!!url('assets/js/components/bootstrap-select.js')!!}"></script>
<script src="{!!url('assets/js/bootstrap-datepicker.js')!!}"></script>
<script src="{!!url('assets/select2-4.0.0/js/select2.min.js')!!}"></script>
<script src="{!!url('assets/js/jquery.ui.widget.js')!!}"></script>
<script src="{!!url('assets/js/jquery.fileupload.js')!!}"></script>

<script>

    (function() {
        // Reset Current
        $('#inlineDatepicker').datepicker( { format: 'dd-mm-yyyy' } );

    })();

    (function(document, window, $) {
        'use strict';

        var Site = window.Site;
        $(document).ready(function() {
            Site.run();
        });
    })(document, window, jQuery);
</script>
<script type="text/javascript">

    $(document).ready(function () {
        jQuery('.clock-wrapper').show(function(){
            jQuery('#clock').makeClock();
        });
    });
    addTimezones();
    function getLastMonday() {
        var result = moment().tz(thisTimeZone);
        while (result.day() !== 1) {
            result.subtract(1, 'day');
        }
        return result;
    }

    function getQuarterDate() {
        var result = moment().tz(thisTimeZone);
        result.subtract(1, 'month');
        while ((result.month() + 1) % 3 != 0) {
            result.subtract(1, 'month');
        }
        return result.add(1, 'month').startOf('month');
    }

    function getHalfDate() {
        var result = moment().tz(thisTimeZone);
        result.subtract(1, 'month');
        while ((result.month() + 1) % 6 != 0) {
            result.subtract(1, 'month');
        }
        return result.add(1, 'month').startOf('month');
    }

</script>
@yield('scripts')
@section('modals')
    @include('layouts.partials.modals')
@show
</body>
</html>