<li class="site-menu-category">Main Menu</li>
@foreach (Nav::$nav->where('nav', 'main')->sortBy('sort') as $chunk => $c)
  <li class="site-menu-item @if($currentnav==$c['slug']) active @endif" ><a @if($c['title']=='Tutorials') target="_blank" @endif href="{{ $c['link']}}"><i class="site-menu-icon fa {{ $c['icon']}}"></i> <span class="site-menu-title">{{ $c['title']}}</span></a></li>
  @if(isset($c['submenu']))
    <ul class="nav nav-second-level">
      @foreach($c['submenu'] as $cc)
        <li class=""><a href="{{ $cc['link']}}">{{ $cc['title']}}</a></li>
      @endforeach
    </ul>
  @endif
@endforeach
